# Aether iOS 26 Launcher (starter)

A lightweight Android launcher foundation designed for the Samsung Galaxy A21s / Android 12.

## Current starter features
- Registers as an Android Home launcher.
- Reads launchable installed apps and their real Android icons.
- Provides a simple iOS-inspired home screen, dock, app library and app search.
- Uses lightweight native Android Views rather than a heavy rendering framework.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Connect the Galaxy A21s with USB debugging enabled, or use an emulator.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the APK, press Home, and select **Aether Launcher**.

## Important limitations
This is the first runnable project foundation, not a finished iOS clone. Android controls the real lock screen, notification shade, system Control Center equivalents, recents screen and system navigation. A third-party launcher can provide its own visual experiences, but cannot safely replace all system UI without privileged/system-level access. The current version does not yet implement themes, icon packs, widgets, folders, gesture navigation or a custom lock screen.

## Next development milestones
1. Custom icon pack/theme engine, including user-selected Samsung icons where Android exposes them.
2. Home-screen grid, folders, drag-and-drop and persistent layout.
3. Gesture handling and spring-based transitions tuned for the A21s.
4. Optional in-app Control Center-style panel and lock-screen-style view, with clear system limitations.
5. Performance, accessibility and Android 12 device testing.
