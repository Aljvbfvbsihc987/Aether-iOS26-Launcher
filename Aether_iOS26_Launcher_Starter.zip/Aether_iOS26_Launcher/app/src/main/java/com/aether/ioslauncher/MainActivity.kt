package com.aether.ioslauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import kotlin.math.max

data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var grid: GridLayout
    private lateinit var search: EditText
    private lateinit var allApps: List<AppEntry>
    private var drawerOpen = false

    private val ink = Color.rgb(30, 38, 54)
    private val muted = Color.rgb(105, 116, 137)
    private val glass = Color.argb(205, 255, 255, 255)
    private val blue = Color.rgb(91, 133, 226)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(232, 239, 250)
        window.navigationBarColor = Color.rgb(232, 239, 250)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        allApps = loadApps()
        showHome()
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull {
                val name = it.loadLabel(pm)?.toString() ?: return@mapNotNull null
                AppEntry(name, it.activityInfo.packageName, it.loadIcon(pm))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private fun background(): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(205, 222, 248), Color.rgb(238, 225, 246), Color.rgb(224, 239, 238)))
            .apply { cornerRadius = dp(0).toFloat() }

    private fun showHome() {
        drawerOpen = false
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = background()
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val date = TextView(this).apply {
            text = "MONDAY, NOVEMBER 7"
            textSize = 12f
            letterSpacing = .12f
            setTextColor(ink)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val spacer = Space(this)
        val status = TextView(this).apply {
            text = "●  ▮▮▮  100%"
            textSize = 12f
            setTextColor(ink)
        }
        top.addView(date)
        top.addView(spacer, LinearLayout.LayoutParams(0, dp(1), 1f))
        top.addView(status)
        root.addView(top, LinearLayout.LayoutParams(-1, dp(30)))

        val clock = TextView(this).apply {
            text = "9:41"
            textSize = 62f
            letterSpacing = -.04f
            setTextColor(Color.rgb(39, 49, 69))
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        root.addView(clock, LinearLayout.LayoutParams(-1, dp(110)))

        val subtitle = TextView(this).apply {
            text = "Your day, at a glance"
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(24)))

        val spacerMain = Space(this)
        root.addView(spacerMain, LinearLayout.LayoutParams(1, 0, 1f))

        val openDrawer = TextView(this).apply {
            text = "⌕     Search & App Library"
            textSize = 15f
            setTextColor(ink)
            gravity = Gravity.CENTER
            background = rounded(glass, 28)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { showDrawer() }
        }
        root.addView(openDrawer, LinearLayout.LayoutParams(-1, dp(48)))

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.argb(175, 255, 255, 255), 30)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val favorites = allApps.take(4)
        favorites.forEach { dock.addView(appTile(it, compact = true), LinearLayout.LayoutParams(0, dp(62), 1f)) }
        root.addView(dock, LinearLayout.LayoutParams(-1, dp(78)).apply { topMargin = dp(12) })

        root.alpha = 0f
        setContentView(root)
        root.animate().alpha(1f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun showDrawer(filter: String = "") {
        drawerOpen = true
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = background()
            setPadding(dp(18), dp(18), dp(18), dp(10))
        }
        val heading = TextView(this).apply {
            text = "App Library"
            textSize = 30f
            setTextColor(ink)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        root.addView(heading, LinearLayout.LayoutParams(-1, dp(48)))

        search = EditText(this).apply {
            hint = "Search apps"
            textSize = 15f
            singleLine = true
            setTextColor(ink)
            setHintTextColor(muted)
            background = rounded(glass, 24)
            setPadding(dp(16), 0, dp(16), 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8); bottomMargin = dp(12) })

        val scroll = ScrollView(this)
        grid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = false }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val back = TextView(this).apply {
            text = "‹   Home"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(blue)
            setPadding(0, dp(10), 0, dp(8))
            setOnClickListener { showHome() }
        }
        root.addView(back, LinearLayout.LayoutParams(-1, dp(42)))
        setContentView(root)
        renderApps(filter)
        search.setText(filter)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(220).start()
    }

    private fun renderApps(query: String) {
        grid.removeAllViews()
        val filtered = allApps.filter { it.label.contains(query, ignoreCase = true) }
        filtered.forEach { app ->
            val tile = appTile(app)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(104)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            grid.addView(tile, params)
        }
    }

    private fun appTile(app: AppEntry, compact: Boolean = false): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(3), dp(3), dp(3))
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                if (launch != null) startActivity(launch)
            }
        }
        val icon = ImageView(this).apply {
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rounded(Color.argb(35, 255, 255, 255), 18)
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val size = if (compact) dp(48) else dp(54)
        wrap.addView(icon, LinearLayout.LayoutParams(size, size))
        if (!compact) {
            val label = TextView(this).apply {
                text = app.label
                textSize = 10.5f
                maxLines = 2
                gravity = Gravity.CENTER
                setTextColor(ink)
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            wrap.addView(label, LinearLayout.LayoutParams(-1, dp(34)))
        }
        return wrap
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
