plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.aether.ioslauncher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aether.ioslauncher"
        minSdk = 23
        targetSdk = 32
        versionCode = 1
        versionName = "0.1.0"
    }
}
